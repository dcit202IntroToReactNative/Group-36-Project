export default {
  DARK: '#1e1e1e',
  LIGHT: '#FFF',
  PRIMARY: '#dbb2ff',
  ERROR: '#ff0000',
};
